<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    //echo var_dump($_POST);
    
    // 将数据编码为字符串传地址参数
    $param = '';
    $param .= 'sell1='.$_POST['sell1'].'&';
    $param .= 'sell2='.$_POST['sell2'].'&';
    $param .= 'sell3='.$_POST['sell3'].'&';
    $param .= 'sell4='.$_POST['sell4'].'&';
    $param .= 'sell5='.$_POST['sell5'].'&';
    $param .= 'sell6='.$_POST['sell6'].'&';
    $param .= 'sell7='.$_POST['sell7'].'&';
    $param .= 'sell8='.$_POST['sell8'].'&';
    $param .= 'sell9='.$_POST['sell9'].'&';
    $param .= 'sell10='.$_POST['sell10'].'&';
    $param .= 'sell11='.$_POST['sell11'].'&';
    $param .= 'sell12='.$_POST['sell12'];

    echo '<img src="chart.php?'.$param.'&user='.$_POST['user'].'" />';
}

?>

<form action="graph.php" method="post">
    <table>
        <tr>
            <td><label for='user'>公司名称：</label></td>
            <td><input type='text' name='user' id='user' value='' /></td>
        </tr>
        <tr>
            <td><label for='date'>年份：</label></td>
            <td>
                <select name='date'>
                    <?php
                        // 使用的代码生成年份选项
                        for ($i = 2000; $i < 2030; $i++) {
                            echo "<option value=\"$i\">$i</option>";
                        }
                    ?>
                </select>
            </td>
        </tr>
        <?php
            // 使用代码生成月份输入框
            for ($i = 1; $i <= 12; $i++) {
                echo '<tr>';
                echo "<td><label>$i 月销售额：</label></td>";
                echo "<td><input type='text' name='sell$i'></td>";
                echo '</tr>';
            }
        ?>
        <tr>
            <td>
                <input type="submit" value='绘图'>
            </td>
        </tr>
    </table>
</form>

<?php



?>