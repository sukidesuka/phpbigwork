<?php
require_once "./jpgraph/src/jpgraph.php";
require_once "./jpgraph/src/jpgraph_bar.php";

//柱形图模拟数据
$data=array(0=>$_GET['sell1'],1=>$_GET['sell2'],2=>$_GET['sell3'],3=>$_GET['sell4'],
4=>$_GET['sell5'],5=>$_GET['sell6'],6=>$_GET['sell7'],7=>$_GET['sell8'],8=>$_GET['sell9'],
9=>$_GET['sell10'],10=>$_GET['sell11'],11=>$_GET['sell12']);
//创建背景图
$graph=new Graph(400,300);
//设置刻度样式
$graph->SetScale("textlin");
//设置边界范围
$graph->img->SetMargin(30,30,80,30);
//设置标题
$graph->title->Set($_GET['user'].'sell statistics');
//得到柱形图对象
$barPlot=new BarPlot($data);
//设置柱形图图例
$barPlot->SetLegend("sell");
//显示柱形图代表数据的值
$barPlot->value->show();
//将柱形图加入到背景图
$graph->Add($barPlot);
//设置柱形图填充颜色
$barPlot->setfillcolor("yellow");
//设置边框颜色
$barPlot->setcolor("red");
//将柱形图输出到浏览器
$graph->Stroke();

?>