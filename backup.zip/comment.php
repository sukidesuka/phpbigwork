<?php
session_start();
$user = $_SESSION['user'];
echo '评论页<br>';
// 连接评论数据库
$link = mysqli_connect('localhost:3308', 'root', '', 'php');
// 如果评论表不存在则创建
$sql = 'create table if not exists comment(user varchar(20), text varchar(20));';
$result = mysqli_query($link, $sql);
if (!$result) {
    echo '执行失败'.mysqli_error($link);
}
// 如果是POST模式，则将传入的评论写入到数据库
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $text = $_POST['text'];
    $sql = "insert into comment (user, text) values (\"$user\", \"$text\");";
    $result = mysqli_query($link, $sql);
    if (!$result) {
        echo '执行失败'.mysqli_error($link);
    }
}

// 从数据表中读取已有评论并展示
$sql = 'select * from comment;';
$result = mysqli_query($link, $sql);
$result = $result->fetch_all();

if (count($result) == 0) {
    echo '当前还没有评论<br><br>';
}
else {
    for ($i = 1; $i <= count($result); $i++) {
        echo $i.'楼 '.$result[$i-1][0].'：<br>';
        echo $result[$i-1][1].'<br><br>';
    }
}

?>

<?php
echo '<form action="comment.php" method="post">';
?>

<textarea type="text" name="text" rows="10" cols="40">
在这里输入评论
</textarea><br>
<input type="submit">
</form>